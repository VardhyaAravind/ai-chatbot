from llama_cpp import Llama

llm = Llama(model_path="models/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf", n_ctx=2048)

def ask_model(prompt):
    system_prompt = "TorkeHub is a white-label CRM used by startups for lead management.\n"
    full_prompt = system_prompt + prompt
    output = llm(prompt=full_prompt, max_tokens=256, stop=["</s>"])
    return output["choices"][0]["text"].strip()