from flask import Flask, request, jsonify
from flask_cors import CORS
from chat_model import ask_model

app = Flask(__name__)
CORS(app)

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    question = data.get("question")
    if not question:
        return jsonify({"error": "No question provided"}), 400
    answer = ask_model(question)
    return jsonify({"answer": answer})

if __name__ == '__main__':
    app.run(debug=True)